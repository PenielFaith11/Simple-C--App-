﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project222
{
    // Enum for menu options
    public enum MenuOption
    {
        Register = 1,
        ViewRegisteredMembers,
        PlaceOrder,
        ViewOrders,
        Exit
    }

    // class for members
    public abstract class Member
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public bool IsLecturer { get; set; }
    }

    // class for students
    public class Student : Member
    {
        public int StudentID { get; set; }
    }

    // class for lecturers
    public class Lecturer : Member
    {
        public string Department { get; set; }
    }

    // Class to manage orders
    public class Order
    {
        public Member Member { get; set; }
        public string Meal { get; set; }
    }

    // class to manage the application
    public class BelgiumCampusMenu
    {
        private static List<Member> members = new List<Member>();
        private static List<Order> orders = new List<Order>();
        internal class Program
        {
            static void Main(string[] args)
            {
                int choice;
                do
                {
                    DisplayMenu();
                    choice = GetMenuChoice();
                    ProcessMenuChoice(choice);
                } while (choice != (int)MenuOption.Exit);
            }

            private static void DisplayMenu()
            {
                Console.WriteLine("Belgium Campus Meal Management");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. View registered members");
                Console.WriteLine("3. Place an order");
                Console.WriteLine("4. View placed orders");
                Console.WriteLine("5. Exit");
            }

            private static int GetMenuChoice()
            {
                Console.Write("Enter your choice: ");
                return int.Parse(Console.ReadLine());
            }

            private static void ProcessMenuChoice(int choice)
            {
                switch ((MenuOption)choice)
                {
                    case MenuOption.Register:
                        RegisterMember();
                        break;
                    case MenuOption.ViewRegisteredMembers:
                        ViewRegisteredMembers();
                        break;
                    case MenuOption.PlaceOrder:
                        PlaceOrder();
                        break;
                    case MenuOption.ViewOrders:
                        ViewOrders();
                        break;
                    case MenuOption.Exit:
                        Console.WriteLine("Exiting the application...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }

            private static void RegisterMember()
            {
                Console.Write("Enter name: ");
                string name = Console.ReadLine();
                Console.Write("Enter email: ");
                string email = Console.ReadLine();
                Console.Write("Are you a lecturer? (true/false): ");
                bool isLecturer = bool.Parse(Console.ReadLine());

                Member member;
                if (isLecturer)
                {
                    Console.Write("Enter department: ");
                    string department = Console.ReadLine();
                    member = new Lecturer { Name = name, Email = email, IsLecturer = isLecturer, Department = department };
                }
                else
                {
                    Console.Write("Enter student ID: ");
                    int studentID = int.Parse(Console.ReadLine());
                    member = new Student { Name = name, Email = email, IsLecturer = isLecturer, StudentID = studentID };
                }

                members.Add(member);
                Console.WriteLine("Member registered successfully.");
            }
            

            private static void ViewRegisteredMembers()
            {
                Console.WriteLine("Registered members:");
                foreach (var member in members)
                {
                    Console.WriteLine($"Name: {member.Name}, Email: {member.Email}, Is Lecturer: {member.IsLecturer}");
                }
            }

            private static void PlaceOrder()
            {
                Console.Write("Enter member name: ");
                string name = Console.ReadLine();
                var member = members.Find(m => m.Name == name);
                if (member == null)
                {
                    Console.WriteLine("Member not found.");
                    return;
                }

                Console.WriteLine("Order placed successfully for one plate.");
            }

            private static void ViewOrders()
            {
                Console.WriteLine("Placed orders:");
                foreach (var order in orders)
                {
                    Console.WriteLine($"Member: {order.Member.Name}, Meal: {order.Meal}");
                    Console.ReadKey();
                }
            }
        }

    }
}   
